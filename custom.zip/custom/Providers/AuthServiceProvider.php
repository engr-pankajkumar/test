<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use App\Extensions\CustomAuthProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Facades\App\Repositories\UserRepository;
class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        // 'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Auth::provider('custom', function ($app, array $config) {
            return new CustomAuthProvider();
        });


       $getPermission = UserRepository::getRolePermission();
       foreach($getPermission as $permission) {

        $moduleId   =   $permission['ModuleId'];
        $roleId     =   $permission['RoleId'];
        $isRead     =   $permission['IsRead'];
        $isWrite    =   $permission['IsWrite'];
      
    if($isRead == 1) { //For IsRead True condition start here
        $readParam = $moduleId.'_isRead';        
       Gate::define($readParam, function ($user, $roleArray) use($readParam, $moduleId) {
            if(count($roleArray->amproRole)) {
                return UserRepository::validateRolePermission($roleArray->amproRole, $moduleId, 1, 'IsRead');    
            }
            
   
        });
   } //For IsRead True condition ends here

   if($isWrite == 1) { //For IsRead True condition start here

        $writeParam = $moduleId.'_isWrite';        
       Gate::define($writeParam, function ($user, $roleArray) use($writeParam, $moduleId) {
         if(count($roleArray->amproRole)) {
            return UserRepository::validateRolePermission($roleArray->amproRole, $moduleId, 1, 'IsWrite');
        }
   
        });
   } //For IsRead True condition ends here

   }//End foreach 




    }
}
