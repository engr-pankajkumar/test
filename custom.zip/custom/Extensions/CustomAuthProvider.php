<?php
namespace App\Extensions;

use Illuminate\Contracts\Auth\UserProvider;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Auth\GenericUser;

class CustomAuthProvider implements UserProvider
{

    public function __construct()
    {}

    /**
     * Retrieve a user by the given credentials.
     *
     * @param array $credentials            
     * @return \Illuminate\Contracts\Auth\Authenticatable|null
     */
    public function retrieveByCredentials(array $credentials)
    {
        if (empty($credentials)) {
            return;
        }
        return $this->customUser();
    }

    protected function customUser()
    {
        $attr = session('user');
        return new GenericUser($attr);
    }

    /**
     * Validate a user against the given credentials.
     *
     * @param \Illuminate\Contracts\Auth\Authenticatable $user            
     * @param array $credentials
     *            Request credentials
     * @return bool
     */
    public function validateCredentials(Authenticatable $user, Array $credentials)
    {
        return true;
    }

    public function retrieveById($identifier)
    {
        return $this->customUser();
    }

    public function retrieveByToken($identifier, $token)
    {}

    public function updateRememberToken(Authenticatable $user, $token)
    {}
     public function getRememberToken()
    {        
    
    }
    public function getRememberTokenName(){
        
    }
    public function setRememberToken($value)
    {        
    }
}